
ChatterDB = {
	["namespaces"] = {
		["PlayerNames"] = {
		},
		["AltLinks"] = {
		},
		["Scrollback"] = {
		},
		["Invite Links"] = {
			["profiles"] = {
				["Default"] = {
					["words"] = {
						["inv"] = "inv",
						["invite"] = "invite",
					},
				},
			},
		},
		["ChannelColors"] = {
			["profiles"] = {
				["Default"] = {
					["colors"] = {
						["RealID Conversation"] = {
							["r"] = 0,
							["g"] = 0.6941176881082356,
							["b"] = 0.9411765262484551,
						},
						["General"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.752941220998764,
							["b"] = 0.752941220998764,
						},
						["Raid Leader"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.2823529578745365,
							["b"] = 0.03529411973431706,
						},
						["Party"] = {
							["r"] = 0.6666667060926557,
							["g"] = 0.6666667060926557,
							["b"] = 1.000000059138984,
						},
						["Whisper"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.501960813999176,
							["b"] = 1.000000059138984,
						},
						["Raid"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.4980392451398075,
							["b"] = 0,
						},
						["Battleground Leader"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.8588235802017152,
							["b"] = 0.717647101264447,
						},
						["Raid Warning"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.2823529578745365,
							["b"] = 0,
						},
						["Party Leader"] = {
							["r"] = 0.4627451254054904,
							["g"] = 0.7843137718737125,
							["b"] = 1.000000059138984,
						},
						["Yell"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.250980406999588,
							["b"] = 0.250980406999588,
						},
						["LocalDefense"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.752941220998764,
							["b"] = 0.752941220998764,
						},
						["Officer"] = {
							["r"] = 0.250980406999588,
							["g"] = 0.752941220998764,
							["b"] = 0.250980406999588,
						},
						["Say"] = {
							["r"] = 1.000000059138984,
							["g"] = 1.000000059138984,
							["b"] = 1.000000059138984,
						},
						["world"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.752941220998764,
							["b"] = 0.752941220998764,
						},
						["RealID Whisper"] = {
							["r"] = 0,
							["g"] = 1.000000059138984,
							["b"] = 0.9647059394046664,
						},
						["Guild"] = {
							["r"] = 0.250980406999588,
							["g"] = 1.000000059138984,
							["b"] = 0.250980406999588,
						},
						["Battleground"] = {
							["r"] = 1.000000059138984,
							["g"] = 0.4980392451398075,
							["b"] = 0,
						},
					},
				},
			},
		},
		["StickyChannels"] = {
		},
		["RealIdPolish"] = {
		},
		["ChatFrameBorders"] = {
			["profiles"] = {
				["Default"] = {
					["frames"] = {
						["FRAME_1"] = {
							["background"] = "Blizzard Dialog Background",
							["border"] = "None",
							["backgroundColor"] = {
								["r"] = 1,
								["g"] = 1,
								["b"] = 1,
							},
						},
					},
				},
			},
		},
		["Buttons"] = {
		},
		["Server Positioning"] = {
		},
		["Mousewheel Scroll"] = {
		},
		["Timestamps"] = {
		},
		["EditBox"] = {
		},
		["ChatFont"] = {
			["profiles"] = {
				["Default"] = {
					["outline"] = "OUTLINE",
					["font"] = "Friz Quadrata TT",
				},
			},
		},
		["ChatTabs"] = {
		},
		["ChannelNames"] = {
			["profiles"] = {
				["Default"] = {
					["channels"] = {
						["world"] = "[CC]",
					},
				},
			},
		},
		["CopyChat"] = {
		},
		["UrlCopy"] = {
		},
		["Editbox History"] = {
			["realm"] = {
				["ChromieCraft"] = {
					["history"] = {
						"/reload", -- [1]
						"/reload", -- [2]
						"/reload", -- [3]
						"/chatter", -- [4]
						"/reload", -- [5]
						"/reload", -- [6]
						"/reload", -- [7]
						"/s sx", -- [8]
						"/s dwlrkldsjflksd", -- [9]
						"/chatter", -- [10]
						"/reload", -- [11]
						"/reload", -- [12]
						"/dominos", -- [13]
						"/dominos", -- [14]
						"/reload", -- [15]
						"/dominos", -- [16]
						"/dominos", -- [17]
						"/dominos", -- [18]
						"/reload", -- [19]
						"/RELOAD", -- [20]
						"/reload", -- [21]
						"/cn", -- [22]
						"/reload", -- [23]
						"/s cn", -- [24]
						"/cn", -- [25]
						"/gathermate", -- [26]
						"/gathermate", -- [27]
						"/cn", -- [28]
						"/questie", -- [29]
						"/tptp", -- [30]
						"/tptp", -- [31]
						"/reload", -- [32]
					},
				},
			},
		},
		["Highlight"] = {
		},
		["JustifyText"] = {
		},
	},
	["profileKeys"] = {
		["Razthion - ChromieCraft"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["modules"] = {
				["Borders/Background"] = false,
				["Timestamps"] = false,
			},
			["welcomeMessaged"] = true,
		},
	},
}
