
DominosDB = {
	["profileKeys"] = {
		["Razkain - Blackrock [PvP only]"] = "Druid",
		["Razthion - ChromieCraft"] = "Druid",
		["Murfasa - Lordaeron"] = "Druid",
		["Razkuff - Icecrown"] = "Druid",
	},
	["profiles"] = {
		["Hunter"] = {
			["frames"] = {
				{
					["y"] = 0,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["HUNTER"] = {
							["[bar:6]"] = 5,
							["[bar:4]"] = 3,
							["[bar:3]"] = 2,
							["[bar:5]"] = 4,
							["[bar:2]"] = 1,
						},
						["MAGE"] = {
							["[bar:6]"] = 5,
							["[bar:5]"] = 4,
							["[bar:3]"] = 2,
							["[bar:4]"] = 3,
							["[bar:2]"] = 1,
						},
					},
					["numButtons"] = 12,
				}, -- [1]
				{
					["y"] = 40,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [2]
				{
					["y"] = 80,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [3]
				{
					["y"] = 120,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [4]
				{
					["y"] = 160,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [5]
				{
					["y"] = 200,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [6]
				{
					["y"] = 240,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [7]
				{
					["y"] = 280,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [8]
				{
					["y"] = 320,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [9]
				{
					["y"] = 360,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [10]
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["numButtons"] = 3,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
				},
				["bags"] = {
					["point"] = "BOTTOMRIGHT",
					["numButtons"] = 6,
					["spacing"] = 2,
				},
				["xp"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "TOP",
					["height"] = 14,
					["width"] = 0.75,
					["alwaysShowText"] = true,
					["texture"] = "blizzard",
				},
				["roll"] = {
					["numButtons"] = 4,
					["point"] = "LEFT",
					["columns"] = 1,
					["spacing"] = 2,
				},
			},
		},
		["Mage"] = {
			["frames"] = {
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 0,
					["pages"] = {
						["MAGE"] = {
							["[bar:6]"] = 5,
							["[bar:5]"] = 4,
							["[bar:3]"] = 2,
							["[bar:4]"] = 3,
							["[bar:2]"] = 1,
						},
					},
					["numButtons"] = 12,
				}, -- [1]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 40,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [2]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 80,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [3]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 120,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [4]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 160,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [5]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 200,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [6]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 240,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [7]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [8]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [9]
				{
					["padW"] = 2,
					["x"] = 0,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360,
					["pages"] = {
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [10]
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
				},
				["roll"] = {
					["numButtons"] = 4,
					["point"] = "LEFT",
					["columns"] = 1,
					["spacing"] = 2,
				},
				["xp"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "TOP",
					["height"] = 14,
					["texture"] = "blizzard",
					["alwaysShowText"] = true,
					["width"] = 0.75,
				},
				["bags"] = {
					["numButtons"] = 6,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["numButtons"] = 3,
				},
			},
		},
		["Druid"] = {
			["showMinimap"] = false,
			["frames"] = {
				{
					["point"] = "BOTTOMLEFT",
					["scale"] = 0.9,
					["y"] = 37.85981915268074,
					["x"] = 52.67484117576539,
					["padW"] = 2,
					["spacing"] = 20,
					["padH"] = 2,
					["numButtons"] = 7,
					["pages"] = {
						["HUNTER"] = {
							["[bar:6]"] = 5,
							["[bar:4]"] = 3,
							["[bar:3]"] = 2,
							["[bar:5]"] = 4,
							["[bar:2]"] = 1,
						},
						["DRUID"] = {
							["[bar:6]"] = 5,
							["[bar:3]"] = 2,
							["[bar:4]"] = 3,
							["[bar:2]"] = 1,
							["[bonusbar:2]"] = 7,
							["[bonusbar:4]"] = 9,
							["[bonusbar:3]"] = 8,
							["[bar:5]"] = 4,
							["[bonusbar:1]"] = 6,
						},
						["MAGE"] = {
							["[bar:6]"] = 5,
							["[bar:5]"] = 4,
							["[bar:3]"] = 2,
							["[bar:4]"] = 3,
							["[bar:2]"] = 1,
						},
					},
					["hspacing"] = 20,
				}, -- [1]
				{
					["point"] = "BOTTOMLEFT",
					["scale"] = 0.89,
					["padW"] = 2,
					["x"] = 450.1368988069231,
					["y"] = 38.73467248769731,
					["spacing"] = 20,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["DRUID"] = {
						},
						["MAGE"] = {
						},
					},
					["numButtons"] = 12,
					["hspacing"] = 20,
				}, -- [2]
				{
					["point"] = "BOTTOMLEFT",
					["scale"] = 0.9,
					["padW"] = 2,
					["x"] = 482.9463870713651,
					["y"] = 97.28397972154221,
					["spacing"] = 20,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["DRUID"] = {
						},
						["MAGE"] = {
						},
					},
					["numButtons"] = 11,
					["hspacing"] = 20,
				}, -- [3]
				{
					["point"] = "BOTTOMLEFT",
					["scale"] = 0.6,
					["columns"] = 6,
					["padW"] = 2,
					["x"] = 17.77775856856207,
					["pages"] = {
						["HUNTER"] = {
						},
						["DRUID"] = {
						},
						["MAGE"] = {
						},
					},
					["spacing"] = 20,
					["padH"] = 2,
					["y"] = 335.604567474304,
					["numButtons"] = 12,
					["hspacing"] = 20,
				}, -- [4]
				{
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.5,
					["columns"] = 2,
					["padW"] = 2,
					["x"] = -14.81327568653796,
					["pages"] = {
						["HUNTER"] = {
						},
						["DRUID"] = {
						},
						["MAGE"] = {
						},
					},
					["spacing"] = 20,
					["padH"] = 2,
					["y"] = 100.4448576249481,
					["numButtons"] = 12,
					["hspacing"] = 20,
				}, -- [5]
				{
					["point"] = "BOTTOMLEFT",
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 518.5185709993926,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 200.0000027354896,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["DRUID"] = {
						},
						["MAGE"] = {
						},
					},
				}, -- [6]
				{
					["point"] = "BOTTOMLEFT",
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 518.5185709993926,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 239.9999857754542,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["DRUID"] = {
						},
						["MAGE"] = {
						},
					},
				}, -- [7]
				{
					["point"] = "BOTTOMLEFT",
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 518.5185709993926,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280.0000213368187,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["DRUID"] = {
						},
						["MAGE"] = {
						},
					},
				}, -- [8]
				{
					["point"] = "BOTTOMLEFT",
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 518.5185709993926,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320.0000043767834,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["DRUID"] = {
						},
						["MAGE"] = {
						},
					},
				}, -- [9]
				{
					["point"] = "BOTTOMLEFT",
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 518.5185709993926,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360.0000224310145,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["DRUID"] = {
						},
						["MAGE"] = {
						},
					},
				}, -- [10]
				["roll"] = {
					["y"] = -195.2221835074462,
					["x"] = 630.5187055854799,
					["point"] = "TOPLEFT",
					["spacing"] = 2,
					["numButtons"] = 4,
					["hidden"] = true,
					["columns"] = 1,
				},
				["menu"] = {
					["y"] = 196.1480832663879,
					["x"] = -247.5556268302562,
					["point"] = "BOTTOMRIGHT",
					["hidden"] = true,
				},
				["xp"] = {
					["y"] = 0,
					["alwaysShowXP"] = 1,
					["point"] = "BOTTOMLEFT",
					["height"] = 2,
					["x"] = 0,
					["texture"] = "Blizzard Character Skills Bar",
					["width"] = 1,
				},
				["vehicle"] = {
					["y"] = 411.6666890748855,
					["x"] = 469.5185558858128,
					["point"] = "BOTTOMLEFT",
					["hidden"] = true,
					["numButtons"] = 3,
				},
				["class"] = {
					["y"] = 196.0491154418318,
					["x"] = 157.8187359288981,
					["point"] = "BOTTOMLEFT",
					["spacing"] = 20,
					["scale"] = 0.9,
					["numButtons"] = 0,
					["hspacing"] = 20,
				},
				["pet"] = {
					["y"] = 379.6666956400604,
					["x"] = -581.5184803863003,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 6,
					["hidden"] = true,
				},
				["bags"] = {
					["y"] = 255.4075060876611,
					["x"] = -291.5556747013238,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
					["hidden"] = true,
					["numButtons"] = 6,
				},
			},
			["sticky"] = false,
			["showgrid"] = false,
		},
	},
}
DominosVersion = "1.18.7"
