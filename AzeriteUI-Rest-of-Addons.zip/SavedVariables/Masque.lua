
MasqueDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["Razkuff - Blackrock [PvP only]"] = "Default",
		["Razthion - ChromieCraft"] = "Default",
		["Razkuff - Icecrown"] = "Default",
		["Murfasa - Lordaeron"] = "Default",
		["Razkain - Blackrock [PvP only]"] = "Default",
		["Thazdingo - Blackrock [PvP only]"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["Groups"] = {
				["Bagnon"] = {
					["SkinID"] = "DiabolicUI BagButton",
					["Backdrop"] = true,
					["Inherit"] = false,
				},
				["Blizzard Action Bars_StanceBar"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["Dominos_Class Bar"] = {
					["SkinID"] = "Azerite",
					["Inherit"] = false,
				},
				["Bagnon_inventory"] = {
					["SkinID"] = "DiabolicUI BagButton",
					["Inherit"] = false,
				},
				["Blizzard Action Bars_ActionBar"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["Blizzard Action Bars_MultiBarBottomRight"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["AdiBags_Bank button"] = {
					["SkinID"] = "DiabolicUI BagButton",
					["Backdrop"] = true,
					["Inherit"] = false,
				},
				["AdiBags_Backpack button"] = {
					["SkinID"] = "DiabolicUI BagButton",
					["Backdrop"] = true,
					["Inherit"] = false,
				},
				["Bagnon_guildbank"] = {
					["SkinID"] = "DiabolicUI BagButton",
					["Backdrop"] = true,
					["Inherit"] = false,
				},
				["Dominos_Pet Bar"] = {
					["SkinID"] = "Azerite",
					["Inherit"] = false,
				},
				["Dominos_Bag Bar"] = {
					["Disabled"] = true,
					["SkinID"] = "Azerite",
					["Inherit"] = false,
				},
				["Dominos_Action Bar"] = {
					["SkinID"] = "Azerite",
					["Inherit"] = false,
				},
				["Blizzard Action Bars_OverrideActionBar"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["ElvUI_ActionBars"] = {
					["SkinID"] = "Azerite HEX",
					["Inherit"] = false,
				},
				["Bagnon_bank"] = {
					["SkinID"] = "DiabolicUI BagButton",
					["Backdrop"] = true,
					["Inherit"] = false,
				},
				["Blizzard Action Bars_MultiBarLeft"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["ElvUI"] = {
					["SkinID"] = "Azerite HEX",
					["Inherit"] = false,
				},
				["Blizzard Action Bars_PossessBar"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["Dominos"] = {
					["SkinID"] = "Azerite",
					["Inherit"] = false,
				},
				["ElvUI_Auras"] = {
					["SkinID"] = "Azerite HEX",
					["Inherit"] = false,
				},
				["Blizzard Action Bars"] = {
					["Inherit"] = false,
				},
				["Blizzard Action Bars_MultiBarRight"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["AdiBags"] = {
					["SkinID"] = "DiabolicUI BagButton",
					["Backdrop"] = true,
					["Inherit"] = false,
				},
				["Blizzard Action Bars_PetBar"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["Blizzard Action Bars_MultiBarBottomLeft"] = {
					["Upgraded"] = true,
					["Inherit"] = false,
				},
				["Masque"] = {
					["SkinID"] = "Azerite HEX",
				},
			},
		},
	},
}
