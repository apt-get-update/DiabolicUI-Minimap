
ThreatPlatesDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["char"] = {
		["Razkain - Blackrock [PvP only]"] = {
			["welcome"] = true,
			["spec"] = {
				["primary"] = false,
			},
			["specInfo"] = {
				{
					13, -- [1]
					nil, -- [2]
					58, -- [3]
				}, -- [1]
			},
			["specName"] = {
				"Balance", -- [1]
				"Feral Combat", -- [2]
				"Restoration", -- [3]
			},
		},
		["Razthion - ChromieCraft"] = {
			["welcome"] = true,
			["spec"] = {
				["primary"] = false,
			},
			["specInfo"] = {
				{
					[3] = 10,
				}, -- [1]
			},
			["specName"] = {
				"Arcane", -- [1]
				"Fire", -- [2]
				"Frost", -- [3]
			},
		},
		["Murfasa - Lordaeron"] = {
			["spec"] = {
				["primary"] = false,
			},
			["welcome"] = true,
			["specName"] = {
				"Beast Mastery", -- [1]
				"Marksmanship", -- [2]
				"Survival", -- [3]
			},
		},
		["Razkuff - Icecrown"] = {
			["spec"] = {
				["primary"] = false,
			},
			["welcome"] = true,
			["specName"] = {
				"Balance", -- [1]
				"Feral Combat", -- [2]
				"Restoration", -- [3]
			},
		},
	},
	["profileKeys"] = {
		["Razkain - Blackrock [PvP only]"] = "Default",
		["Razthion - ChromieCraft"] = "Default",
		["Murfasa - Lordaeron"] = "Blizz",
		["Razkuff - Icecrown"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["nameplate"] = {
				["toggle"] = {
					["Totem"] = true,
				},
				["scale"] = {
					["Elite"] = 1,
				},
			},
			["OldSetting"] = false,
			["allowClass"] = true,
			["uniqueSettings"] = {
				[31] = {
				},
				[32] = {
				},
				[33] = {
				},
				[37] = {
				},
				[39] = {
				},
				[40] = {
				},
				[41] = {
				},
				[47] = {
				},
				[48] = {
				},
				[49] = {
				},
				["list"] = {
					"Shadow Fiend", -- [1]
					"Spirit Wolf", -- [2]
					"Ebon Gargoyle", -- [3]
					"Water Elemental", -- [4]
					"Treant", -- [5]
					"Viper", -- [6]
					"Venomous Snake", -- [7]
					"Army of the Dead Ghoul", -- [8]
					"Shadowy Apparition", -- [9]
					"Shambling Horror", -- [10]
					"Web Wrap", -- [11]
					"Immortal Guardian", -- [12]
					"Marked Immortal Guardian", -- [13]
					"Empowered Adherent", -- [14]
					"Deformed Fanatic", -- [15]
					"Reanimated Adherent", -- [16]
					"Reanimated Fanatic", -- [17]
					"Bone Spike", -- [18]
					"Onyxian Whelp", -- [19]
					"Gas Cloud", -- [20]
					"Volatile Ooze", -- [21]
					"Darnavan", -- [22]
					"Val'kyr Shadowguard", -- [23]
					"Kinetic Bomb", -- [24]
					"Lich King", -- [25]
					"Raging Spirit", -- [26]
					"Drudge Ghoul", -- [27]
					"Living Inferno", -- [28]
					"Living Ember", -- [29]
					"Fanged Pit Viper", -- [30]
					"", -- [31]
					"", -- [32]
					"", -- [33]
					"", -- [34]
					"", -- [35]
					"", -- [36]
					"", -- [37]
					"", -- [38]
					"", -- [39]
					"", -- [40]
					"", -- [41]
					"", -- [42]
					"", -- [43]
					"", -- [44]
					"", -- [45]
					"", -- [46]
					"", -- [47]
					"", -- [48]
					"", -- [49]
					"", -- [50]
				},
			},
			["threat"] = {
				["art"] = {
					["theme"] = "bar",
				},
				["useAlpha"] = false,
				["useScale"] = false,
				["ON"] = false,
			},
			["settings"] = {
				["customtext"] = {
					["flags"] = "OUTLINE",
					["vertical"] = "BOTTOM",
					["typeface"] = "Friz Quadrata TT",
					["y"] = -10,
					["size"] = 9,
				},
				["highlight"] = {
					["height"] = 72,
					["width"] = 160,
					["texture"] = "Empty",
				},
				["eliteicon"] = {
					["y"] = 0,
					["x"] = 0,
					["anchor"] = "RIGHT",
					["scale"] = 26,
				},
				["spellicon"] = {
					["show"] = false,
				},
				["elitehealthborder"] = {
					["show"] = false,
				},
				["spelltext"] = {
					["y"] = -22,
					["vertical"] = "BOTTOM",
					["typeface"] = "Friz Quadrata TT",
					["flags"] = "OUTLINE",
					["size"] = 8,
				},
				["target"] = {
					["texture"] = "Empty",
				},
				["level"] = {
					["align"] = "LEFT",
					["flags"] = "OUTLINE",
					["x"] = -16,
					["typeface"] = "Friz Quadrata TT",
					["vertical"] = "CENTER",
					["size"] = 9,
				},
				["healthbar"] = {
					["height"] = 18,
					["width"] = 70,
				},
				["healthborder"] = {
					["show"] = false,
					["height"] = 72,
					["width"] = 160,
				},
				["threatborder"] = {
					["height"] = 72,
					["show"] = false,
					["width"] = 160,
				},
				["castborder"] = {
					["y"] = -12,
					["height"] = 72,
					["width"] = 160,
				},
				["name"] = {
					["flags"] = "OUTLINE",
					["typeface"] = "Friz Quadrata TT",
					["y"] = 14,
					["size"] = 10,
				},
				["frame"] = {
					["height"] = 38,
					["width"] = 74,
				},
				["castbar"] = {
					["show"] = false,
					["y"] = -12,
					["width"] = 70,
				},
				["castnostop"] = {
					["y"] = -12,
					["height"] = 72,
					["width"] = 160,
				},
			},
			["targetWidget"] = {
				["ON"] = false,
			},
			["friendlyClass"] = true,
			["cacheClass"] = true,
			["text"] = {
				["max"] = true,
				["full"] = true,
				["percent"] = false,
			},
			["debuffWidget"] = {
				["mode"] = "allMine",
			},
		},
		["Blizz"] = {
			["nameplate"] = {
				["toggle"] = {
					["Totem"] = true,
				},
			},
			["uniqueSettings"] = {
				[32] = {
				},
				[49] = {
				},
				[40] = {
				},
				[31] = {
				},
				[33] = {
				},
				[37] = {
				},
				["list"] = {
					"Shadow Fiend", -- [1]
					"Spirit Wolf", -- [2]
					"Ebon Gargoyle", -- [3]
					"Water Elemental", -- [4]
					"Treant", -- [5]
					"Viper", -- [6]
					"Venomous Snake", -- [7]
					"Army of the Dead Ghoul", -- [8]
					"Shadowy Apparition", -- [9]
					"Shambling Horror", -- [10]
					"Web Wrap", -- [11]
					"Immortal Guardian", -- [12]
					"Marked Immortal Guardian", -- [13]
					"Empowered Adherent", -- [14]
					"Deformed Fanatic", -- [15]
					"Reanimated Adherent", -- [16]
					"Reanimated Fanatic", -- [17]
					"Bone Spike", -- [18]
					"Onyxian Whelp", -- [19]
					"Gas Cloud", -- [20]
					"Volatile Ooze", -- [21]
					"Darnavan", -- [22]
					"Val'kyr Shadowguard", -- [23]
					"Kinetic Bomb", -- [24]
					"Lich King", -- [25]
					"Raging Spirit", -- [26]
					"Drudge Ghoul", -- [27]
					"Living Inferno", -- [28]
					"Living Ember", -- [29]
					"Fanged Pit Viper", -- [30]
					"", -- [31]
					"", -- [32]
					"", -- [33]
					"", -- [34]
					"", -- [35]
					"", -- [36]
					"", -- [37]
					"", -- [38]
					"", -- [39]
					"", -- [40]
					"", -- [41]
					"", -- [42]
					"", -- [43]
					"", -- [44]
					"", -- [45]
					"", -- [46]
					"", -- [47]
					"", -- [48]
					"", -- [49]
					"", -- [50]
				},
				[39] = {
				},
				[41] = {
				},
				[48] = {
				},
				[47] = {
				},
			},
			["cache"] = {
			},
		},
	},
}
